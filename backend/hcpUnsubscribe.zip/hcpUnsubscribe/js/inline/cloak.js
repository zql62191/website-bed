(function() {
    document.documentElement.className += ' ng-cloak';
})();
